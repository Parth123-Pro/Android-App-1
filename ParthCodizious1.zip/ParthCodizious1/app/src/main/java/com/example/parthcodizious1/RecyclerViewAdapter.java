package com.example.parthcodizious1;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public  class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.MyViewHolder> {

     Context mContext;
      List<Nrccab> mData;

    public RecyclerViewAdapter(Context mContext, List<Nrccab> mData) {
        this.mContext = mContext;
        this.mData = mData;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

       View view1;
        LayoutInflater layoutInflater = LayoutInflater.from(mContext);
        view1=layoutInflater.inflate(R.layout.cardview_file,parent,false);


        return new MyViewHolder(view1);
    }

    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, final int position) {

//
        holder.tv_title.setText(mData.get(position).getTitle());

//        holder.aucimg.setImageResource(mData.get(position).getThumbnail());
//        holder.cv.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent intent=new Intent(mContext, MotocActivity.class);
//                intent.putExtra("Title",mData.get(position).getTitle());
//                intent.putExtra("Thumbnail",mData.get(position).getThumbnail());
//                intent.putExtra("Price",mData.get(position).getPrice());
//                intent.putExtra("Detail",mData.get(position).getDetail());
//
//                mContext.startActivity(intent);
//            }
//        });  holder.cv.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent intent=new Intent(mContext, MotocActivity.class);
//                intent.putExtra("Title",mData.get(position).getTitle());
//                intent.putExtra("Thumbnail",mData.get(position).getThumbnail());
//                intent.putExtra("Price",mData.get(position).getPrice());
//                intent.putExtra("Detail",mData.get(position).getDetail());
//                mContext.startActivity(intent);
//            }
//        });
//

    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{

        TextView tv_title;

        CardView cv;

        public MyViewHolder(View view){
            super(view);

            tv_title=(TextView) view.findViewById(R.id.cvt1);

            cv=(CardView)view.findViewById(R.id.card123);

        }
    }



}
