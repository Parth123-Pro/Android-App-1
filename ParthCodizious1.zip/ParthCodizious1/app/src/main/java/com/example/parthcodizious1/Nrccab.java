package com.example.parthcodizious1;

public class Nrccab {

    private String Title;

    private String Detail;





    public Nrccab(String title, String detail) {
        Title = title;
        Detail = detail;

    }



    public String getTitle() {
        return Title;
    }

    public void setTitle(String title) {
        Title = title;
    }


    public String getDetail() {
        return Detail;
    }

    public void setDetail(String detail) {
        Detail = detail;
    }

}
