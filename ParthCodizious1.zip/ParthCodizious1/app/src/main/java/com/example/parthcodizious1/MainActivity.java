package com.example.parthcodizious1;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView nrc,caa,cab;
    ViewPager viewPager;
   PagerAdepter pagerAdepter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nrc=(TextView)findViewById(R.id.Nrc);
        cab=(TextView)findViewById(R.id.Cab);
        caa=(TextView)findViewById(R.id.Caa);
        viewPager=(ViewPager)findViewById(R.id.fragment_container);

        pagerAdepter = new PagerAdepter(getSupportFragmentManager());


        viewPager.setAdapter(pagerAdepter);

        nrc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                viewPager.setCurrentItem(0);
            }
        });

        cab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                viewPager.setCurrentItem(1);
            }
        });

        caa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                viewPager.setCurrentItem(2);
            }
        });

        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onPageSelected(int position) {

                onChangeTab(position);
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });




    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private void onChangeTab(int position) {

        if(position==0){

                nrc.setTextSize(25);
                nrc.setTextColor(getColor(R.color.bright_color));

            cab.setTextSize(20);
            cab.setTextColor(getColor(R.color.light_color));

            caa.setTextSize(20);
            caa.setTextColor(getColor(R.color.light_color));
        }

        if(position==1){

            nrc.setTextSize(20);
            nrc.setTextColor(getColor(R.color.light_color));

            cab.setTextSize(25);
            cab.setTextColor(getColor(R.color.bright_color));

            caa.setTextSize(20);
            caa.setTextColor(getColor(R.color.light_color));
        }

        if(position==2){

            nrc.setTextSize(20);
            nrc.setTextColor(getColor(R.color.light_color));

            cab.setTextSize(20);
            cab.setTextColor(getColor(R.color.light_color));

            caa.setTextSize(25);
            caa.setTextColor(getColor(R.color.bright_color));
        }
    }
}
