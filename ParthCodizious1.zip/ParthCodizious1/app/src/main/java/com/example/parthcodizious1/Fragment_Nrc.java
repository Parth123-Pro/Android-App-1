package com.example.parthcodizious1;


import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class Fragment_Nrc extends Fragment {

    View v;
    private List<Nrccab> nrccabs;

    @Nullable
    @Override
    public android.view.View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        v=inflater.inflate(R.layout.fragment_nrc,null);

        RecyclerView myrecyclerView = (RecyclerView) v.findViewById(R.id.nrcRecycle);

        RecyclerViewAdapter recyclerViewAdapter = new RecyclerViewAdapter(getContext(),nrccabs);
        myrecyclerView.setLayoutManager(new GridLayoutManager(getContext(),1));
        myrecyclerView.setAdapter(recyclerViewAdapter);
return v;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        nrccabs = new ArrayList<>();
        nrccabs.add(new Nrccab(" Parth","kjanskjfnhljsanfcl"));
        nrccabs.add(new Nrccab("Renish","lkdjlgkrjdlkjoip"));
        nrccabs.add(new Nrccab("Bhargav","lkdjlgkrjdlkjoip"));
        nrccabs.add(new Nrccab("Chanas","lkdjlgkrjdlkjoip"));


    }
}
